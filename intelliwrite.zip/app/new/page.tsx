import StoryWrapper from '@/components/new-story/story-wrapper'
import React from 'react'

const NewStory = () => {
  return (
    <StoryWrapper/>
  )
}

export default NewStory