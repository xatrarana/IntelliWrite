import React from 'react'

const FeedSettings = () => {
  return (
    <div>FeedSettings</div>
  )
}

export default FeedSettings