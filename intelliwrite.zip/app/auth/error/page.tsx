import { ErroCard } from "@/components/auth/error-card";

const AuthErorPage = () => {
    return (
        <ErroCard/>
    )
}
export default AuthErorPage;